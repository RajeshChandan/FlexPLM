/**
 * SoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.hbi.wc.interfaces.outbound.webservices.measurements;

public class SoapBindingImpl implements com.hbi.wc.interfaces.outbound.webservices.measurements.IEService{
    public java.lang.String hbiMeasurementsTask(com.hbi.wc.interfaces.outbound.webservices.measurements.ComHbiWcInterfacesOutboundWebservicesMeasurementsHBIMeasurementsBean hbiMeasurementsBean) throws java.rmi.RemoteException {
        return null;
    }

}
